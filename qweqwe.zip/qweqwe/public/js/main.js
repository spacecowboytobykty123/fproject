// Import axios for HTTP requests (assuming this script is running in an environment where axios is available)

// const axios = require('axios');

document.addEventListener('DOMContentLoaded', () => {
    // Add event listener for clicks on elements within the .user-list
    document.querySelector(".user-list").addEventListener("click", async (e) => {
        let target = e.target;
        if (target.classList.contains("delete")) {
            const username = target.getAttribute('data-username');
            if (!username) return;

            try {
                // Use fetch to send a DELETE request
                const response = await fetch(`/user/${username}`, { method: 'DELETE' });
                if (response.ok) {
                    target.parentElement.parentElement.remove();
                    showAlert("User Data deleted", "danger");
                } else {
                    showAlert("Failed to delete user", "danger");
                }
            } catch (error) {
                console.error('Error:', error);
                showAlert("An error occurred", "danger");
            }
        }
    });

    // Function to show alerts
    function showAlert(message, className) {
        const div = document.createElement("div");
        div.className = `alert alert-${className}`;
        div.appendChild(document.createTextNode(message));
        const container = document.querySelector(".container");
        const main = document.querySelector(".main");
        container.insertBefore(div, main);
        setTimeout(() => document.querySelector(".alert").remove(), 3000);
    }

    // Function to fetch and display facts
    async function fetchFacts() {
        try {
            const response = await fetch('https://cat-fact.herokuapp.com/facts');
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            displayFacts(data);
        } catch (error) {
            console.error('There has been a problem with your fetch operation:', error);
        }
    }

});

function displayJoke(jokeData) {
    const jokesContainer = document.getElementById('jokes-container'); 
    jokesContainer.innerHTML = '';

    const jokeElement = document.createElement('p');
    jokeElement.textContent = jokeData; 

    jokesContainer.appendChild(jokeElement);
}

async function getRandomJoke() {
    const options = {
        method: 'GET',
        url: 'https://matchilling-chuck-norris-jokes-v1.p.rapidapi.com/jokes/random',
        headers: {
            accept: 'application/json',
            'X-RapidAPI-Key': '29213011b5msh17845e76bb0fb12p1e4ba5jsnc473aadbd65d',
            'X-RapidAPI-Host': 'matchilling-chuck-norris-jokes-v1.p.rapidapi.com'
        }
    };

    try {
        const response = await axios.request(options);
        // console.log(response.data.value);
        displayJoke(response.data.value); // Call displayJoke with the response data
    } catch (error) {
        console.error(error);
    }
}


async function fun() {
    const url = 'https://fun-facts1.p.rapidapi.com/api/fun-facts';
    const options = {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': '29213011b5msh17845e76bb0fb12p1e4ba5jsnc473aadbd65d',
        'X-RapidAPI-Host': 'fun-facts1.p.rapidapi.com'
      }
    };
  
    try {
      const response = await fetch(url, options);
      const result = await response.json();
      
      // Assuming result is an array and taking the first fact, or adjust based on the actual structure
      const fact = result.fact || "No fact found."; // Adjust based on actual API response
      
      const funFactInfoDiv = document.getElementById('funFactInfo');
      funFactInfoDiv.innerHTML = `<p>${fact}</p>`;
    } catch (error) {
      console.error('Error fetching fun fact:', error);
    }
}
async function fetchRandomAnimeGif() {
    const url = 'https://any-anime.p.rapidapi.com/v1/anime/gif/1';
    const options = {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': '29213011b5msh17845e76bb0fb12p1e4ba5jsnc473aadbd65d',
        'X-RapidAPI-Host': 'any-anime.p.rapidapi.com'
      }
    };
  
    try {
      const response = await fetch(url, options);
      const result = await response.json();
      const imageUrl = result.images[0]; 
      console.log(imageUrl);
      const animeGifContainer = document.getElementById('animeGifContainer');
      animeGifContainer.innerHTML = `<img src="${imageUrl}" alt="Anime GIF" class="img-fluid">`; // Added img-fluid class here
      con
    } catch (error) {
      console.error('Error fetching random anime GIF:', error);
    }
}
